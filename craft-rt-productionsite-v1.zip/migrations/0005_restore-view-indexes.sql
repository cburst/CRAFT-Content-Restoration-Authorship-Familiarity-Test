-- Migration 0005:
-- Restore indexes lost during the table rebuild in migration 0004
-- and enforce at most one open view per item.


/* =========================================================
   INSTANCE ITEMS
   ========================================================= */

CREATE UNIQUE INDEX idx_instance_presentation_order
ON instance_items(
	instance_id,
	presentation_order
);


CREATE INDEX idx_instance_active_item
ON instance_items(
	instance_id,
	released_at,
	answered_at
);


/* =========================================================
   ITEM VIEWS
   ========================================================= */

CREATE UNIQUE INDEX idx_item_view_number
ON item_views(
	instance_id,
	item_id,
	view_number
);


CREATE INDEX idx_item_views_instance
ON item_views(
	instance_id
);


/*
 * At most one unfinished/open view may exist for a given
 * test item.
 *
 * Closed historical views are unaffected because the
 * uniqueness constraint applies only while ended_at is NULL.
 */

CREATE UNIQUE INDEX idx_item_views_one_open
ON item_views(
	instance_id,
	item_id
)
WHERE ended_at IS NULL;


/* =========================================================
   SCROLL EVENTS
   ========================================================= */

CREATE UNIQUE INDEX idx_scroll_event_number
ON scroll_events(
	view_id,
	event_number
);


CREATE INDEX idx_scroll_events_view
ON scroll_events(
	view_id
);
