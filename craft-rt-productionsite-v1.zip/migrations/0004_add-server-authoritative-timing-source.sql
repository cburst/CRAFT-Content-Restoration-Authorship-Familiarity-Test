PRAGMA defer_foreign_keys = on;


/* =========================================================
   REBUILD instance_items
   Add 'server_authoritative' to timing_source CHECK
   ========================================================= */

CREATE TABLE instance_items_new (
	instance_id TEXT NOT NULL,
	item_id TEXT NOT NULL,

	original_order INTEGER NOT NULL,
	presentation_order INTEGER NOT NULL,

	question_sentence TEXT NOT NULL,

	answer_key TEXT NOT NULL
		CHECK (
			answer_key IN (
				'original',
				'modified',
				'fabricated'
			)
		),

	released_at TEXT,
	answered_at TEXT,

	response TEXT
		CHECK (
			response IS NULL
			OR response IN (
				'original',
				'modified',
				'fabricated'
			)
		),

	correct INTEGER
		CHECK (
			correct IS NULL
			OR correct IN (0, 1)
		),

	client_rt_ms REAL,
	server_rt_ms REAL,
	scoring_rt_ms REAL,

	timing_source TEXT
		CHECK (
			timing_source IS NULL
			OR timing_source IN (
				'client',
				'server_interruption',
				'server_discrepancy',
				'server_authoritative'
			)
		),

	penalty_ms REAL DEFAULT 0,
	adjusted_rt_ms REAL,

	reload_count INTEGER NOT NULL DEFAULT 0,
	visibility_loss_count INTEGER NOT NULL DEFAULT 0,

	PRIMARY KEY (
		instance_id,
		item_id
	),

	FOREIGN KEY (
		instance_id
	)
		REFERENCES test_instances(
			instance_id
		)
		ON DELETE CASCADE
);


/* =========================================================
   REBUILD item_views
   Add 'server_authoritative' to timing_source CHECK
   ========================================================= */

CREATE TABLE item_views_new (
	view_id TEXT PRIMARY KEY,

	instance_id TEXT NOT NULL,
	item_id TEXT NOT NULL,

	view_number INTEGER NOT NULL,

	started_at TEXT NOT NULL,
	ended_at TEXT,

	navigation_from TEXT
		CHECK (
			navigation_from IS NULL
			OR navigation_from IN (
				'initial',
				'next',
				'previous',
				'reload'
			)
		),

	response TEXT
		CHECK (
			response IS NULL
			OR response IN (
				'original',
				'modified',
				'fabricated'
			)
		),

	response_changed INTEGER NOT NULL DEFAULT 0
		CHECK (
			response_changed IN (0, 1)
		),

	correct INTEGER
		CHECK (
			correct IS NULL
			OR correct IN (0, 1)
		),

	client_rt_ms REAL,
	server_rt_ms REAL,
	scoring_rt_ms REAL,

	timing_source TEXT
		CHECK (
			timing_source IS NULL
			OR timing_source IN (
				'client',
				'server_interruption',
				'server_discrepancy',
				'server_authoritative'
			)
		),

	penalty_ms REAL NOT NULL DEFAULT 0,
	adjusted_rt_ms REAL,

	reload_count INTEGER NOT NULL DEFAULT 0,

	visibility_loss_count INTEGER NOT NULL DEFAULT 0,

	exit_action TEXT
		CHECK (
			exit_action IS NULL
			OR exit_action IN (
				'previous',
				'next',
				'finish'
			)
		),

	answer_saved INTEGER NOT NULL DEFAULT 0
		CHECK (
			answer_saved IN (0, 1)
		),

	FOREIGN KEY (
		instance_id,
		item_id
	)
		REFERENCES instance_items_new(
			instance_id,
			item_id
		)
		ON DELETE CASCADE
);


/* =========================================================
   REBUILD scroll_events
   Preserve foreign key relationship to item_views
   ========================================================= */

CREATE TABLE scroll_events_new (
	scroll_event_id TEXT PRIMARY KEY,

	view_id TEXT NOT NULL,

	event_number INTEGER NOT NULL,

	started_at TEXT NOT NULL,
	ended_at TEXT NOT NULL,

	duration_ms REAL NOT NULL,

	start_scroll_top REAL NOT NULL,
	end_scroll_top REAL NOT NULL,

	distance_px REAL NOT NULL,

	FOREIGN KEY (
		view_id
	)
		REFERENCES item_views_new(
			view_id
		)
		ON DELETE CASCADE
);


/* =========================================================
   COPY EXISTING DATA
   ========================================================= */

INSERT INTO instance_items_new (
	instance_id,
	item_id,
	original_order,
	presentation_order,
	question_sentence,
	answer_key,
	released_at,
	answered_at,
	response,
	correct,
	client_rt_ms,
	server_rt_ms,
	scoring_rt_ms,
	timing_source,
	penalty_ms,
	adjusted_rt_ms,
	reload_count,
	visibility_loss_count
)
SELECT
	instance_id,
	item_id,
	original_order,
	presentation_order,
	question_sentence,
	answer_key,
	released_at,
	answered_at,
	response,
	correct,
	client_rt_ms,
	server_rt_ms,
	scoring_rt_ms,
	timing_source,
	penalty_ms,
	adjusted_rt_ms,
	reload_count,
	visibility_loss_count
FROM instance_items;


INSERT INTO item_views_new (
	view_id,
	instance_id,
	item_id,
	view_number,
	started_at,
	ended_at,
	navigation_from,
	response,
	response_changed,
	correct,
	client_rt_ms,
	server_rt_ms,
	scoring_rt_ms,
	timing_source,
	penalty_ms,
	adjusted_rt_ms,
	reload_count,
	visibility_loss_count,
	exit_action,
	answer_saved
)
SELECT
	view_id,
	instance_id,
	item_id,
	view_number,
	started_at,
	ended_at,
	navigation_from,
	response,
	response_changed,
	correct,
	client_rt_ms,
	server_rt_ms,
	scoring_rt_ms,
	timing_source,
	penalty_ms,
	adjusted_rt_ms,
	reload_count,
	visibility_loss_count,
	exit_action,
	answer_saved
FROM item_views;


INSERT INTO scroll_events_new (
	scroll_event_id,
	view_id,
	event_number,
	started_at,
	ended_at,
	duration_ms,
	start_scroll_top,
	end_scroll_top,
	distance_px
)
SELECT
	scroll_event_id,
	view_id,
	event_number,
	started_at,
	ended_at,
	duration_ms,
	start_scroll_top,
	end_scroll_top,
	distance_px
FROM scroll_events;


/* =========================================================
   REMOVE OLD TABLES
   Child tables first
   ========================================================= */

DROP TABLE scroll_events;

DROP TABLE item_views;

DROP TABLE instance_items;


/* =========================================================
   RENAME REBUILT TABLES
   Parent tables first
   ========================================================= */

ALTER TABLE instance_items_new
	RENAME TO instance_items;


ALTER TABLE item_views_new
	RENAME TO item_views;


ALTER TABLE scroll_events_new
	RENAME TO scroll_events;


/* =========================================================
   VERIFY FOREIGN KEYS
   ========================================================= */

PRAGMA foreign_key_check;

PRAGMA defer_foreign_keys = off;
