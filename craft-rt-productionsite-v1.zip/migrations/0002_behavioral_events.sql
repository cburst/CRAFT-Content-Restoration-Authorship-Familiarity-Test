-- Migration 0002: question-view and scrolling event history

CREATE TABLE item_views (
    view_id TEXT PRIMARY KEY,

    instance_id TEXT NOT NULL,
    item_id TEXT NOT NULL,

    view_number INTEGER NOT NULL,

    started_at TEXT NOT NULL,
    ended_at TEXT,

    navigation_from TEXT
        CHECK (
            navigation_from IS NULL
            OR navigation_from IN (
                'initial',
                'next',
                'previous',
                'reload'
            )
        ),

    response TEXT
        CHECK (
            response IS NULL
            OR response IN (
                'original',
                'modified',
                'fabricated'
            )
        ),

    response_changed INTEGER NOT NULL DEFAULT 0
        CHECK (response_changed IN (0, 1)),

    correct INTEGER
        CHECK (
            correct IS NULL
            OR correct IN (0, 1)
        ),

    client_rt_ms REAL,
    server_rt_ms REAL,
    scoring_rt_ms REAL,

    timing_source TEXT
        CHECK (
            timing_source IS NULL
            OR timing_source IN (
                'client',
                'server_interruption',
                'server_discrepancy'
            )
        ),

    penalty_ms REAL NOT NULL DEFAULT 0,
    adjusted_rt_ms REAL,

    reload_count INTEGER NOT NULL DEFAULT 0,
    visibility_loss_count INTEGER NOT NULL DEFAULT 0,

    FOREIGN KEY (instance_id, item_id)
        REFERENCES instance_items(instance_id, item_id)
        ON DELETE CASCADE
);

CREATE UNIQUE INDEX idx_item_view_number
ON item_views(instance_id, item_id, view_number);

CREATE INDEX idx_item_views_instance
ON item_views(instance_id);

CREATE TABLE scroll_events (
    scroll_event_id TEXT PRIMARY KEY,

    view_id TEXT NOT NULL,

    event_number INTEGER NOT NULL,

    started_at TEXT NOT NULL,
    ended_at TEXT NOT NULL,

    duration_ms REAL NOT NULL,

    start_scroll_top REAL NOT NULL,
    end_scroll_top REAL NOT NULL,

    distance_px REAL NOT NULL,

    FOREIGN KEY (view_id)
        REFERENCES item_views(view_id)
        ON DELETE CASCADE
);

CREATE UNIQUE INDEX idx_scroll_event_number
ON scroll_events(view_id, event_number);

CREATE INDEX idx_scroll_events_view
ON scroll_events(view_id);
