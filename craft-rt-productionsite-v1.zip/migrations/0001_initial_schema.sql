-- Migration number: 0001 	 2026-08-23T06:44:19.280Z
CREATE TABLE test_instances (
    instance_id TEXT PRIMARY KEY,

    source_file TEXT NOT NULL,

    student_name TEXT NOT NULL,
    student_id TEXT NOT NULL,
    email TEXT NOT NULL,

    original_text TEXT NOT NULL,

    access_token TEXT NOT NULL UNIQUE,

    total_items INTEGER NOT NULL,
    current_position INTEGER NOT NULL DEFAULT 0,

    started_at TEXT,
    completed_at TEXT,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE instance_items (
    instance_id TEXT NOT NULL,
    item_id TEXT NOT NULL,

    original_order INTEGER NOT NULL,
    presentation_order INTEGER NOT NULL,

    question_sentence TEXT NOT NULL,
    answer_key TEXT NOT NULL
        CHECK (answer_key IN ('original', 'modified', 'fabricated')),

    released_at TEXT,
    answered_at TEXT,

    response TEXT
        CHECK (
            response IS NULL
            OR response IN ('original', 'modified', 'fabricated')
        ),

    correct INTEGER
        CHECK (
            correct IS NULL
            OR correct IN (0, 1)
        ),

    client_rt_ms REAL,
    server_rt_ms REAL,
    scoring_rt_ms REAL,

    timing_source TEXT
        CHECK (
            timing_source IS NULL
            OR timing_source IN (
                'client',
                'server_interruption',
                'server_discrepancy'
            )
        ),

    penalty_ms REAL DEFAULT 0,
    adjusted_rt_ms REAL,

    reload_count INTEGER NOT NULL DEFAULT 0,
    visibility_loss_count INTEGER NOT NULL DEFAULT 0,

    PRIMARY KEY (instance_id, item_id),

    FOREIGN KEY (instance_id)
        REFERENCES test_instances(instance_id)
        ON DELETE CASCADE
);

CREATE UNIQUE INDEX idx_instance_presentation_order
ON instance_items(instance_id, presentation_order);

CREATE INDEX idx_instance_active_item
ON instance_items(instance_id, released_at, answered_at);

CREATE INDEX idx_access_token
ON test_instances(access_token);
