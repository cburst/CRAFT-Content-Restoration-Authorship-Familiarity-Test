-- Migration 0003: record how each question view ended

ALTER TABLE item_views
ADD COLUMN exit_action TEXT
CHECK (
    exit_action IS NULL
    OR exit_action IN (
        'previous',
        'next',
        'finish'
    )
);

ALTER TABLE item_views
ADD COLUMN answer_saved INTEGER NOT NULL DEFAULT 0
CHECK (answer_saved IN (0, 1));
