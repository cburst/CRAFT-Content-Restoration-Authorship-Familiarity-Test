CRAFT-RT source for GitHub

This archive includes the revised English-Korean instructions in public/test.js.
The interface, timing logic, and scoring implementation are unchanged.

Preparation:
1. Extract this archive and commit the extracted source files to GitHub.
2. Copy wrangler.example.jsonc to wrangler.jsonc locally.
3. Restore your own database ID/name, bucket names, worker name, and service
   binding in your local wrangler.jsonc. Keep that local file out of Git.
4. Configure CRAFT_ADMIN_SECRET through Cloudflare secret storage, never in
   JavaScript, JSON configuration, Git commits, or uploaded test data.
5. Install dependencies with npm ci. Use the existing test/dev/deploy scripts
   only after configuring the local Cloudflare bindings.

Excluded from this source archive:
- All exported participant CSVs and all other CSV/TSV files, including the
  production smoke-test file containing a personal email address.
- Local .wrangler cache, macOS metadata, and the original infrastructure config.
- Existing Git history. This archive cannot remove data from an existing repo.

The SQL migrations are schema migrations, including INSERT ... SELECT data
migration statements; they are not database dumps.

Review the files before publishing. The .gitignore helps prevent accidental
future additions, but does not remove files that Git already tracks.
