const MAX_TEXT_LENGTH = 100000
const MAX_EMAIL_LENGTH = 320
const MAX_NAME_LENGTH = 200
const MAX_STUDENT_LENGTH = 100

function formatKSTTimestamp() {

	const now = new Date()

	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone: "Asia/Seoul",
		year: "numeric",
		month: "numeric",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit",
		second: "2-digit",
		hour12: true
	}).formatToParts(now)

	const values = {}

	for (const part of parts) {
		if (part.type !== "literal") {
			values[part.type] = part.value
		}
	}

	return `${values.month}/${values.day}/${values.year} ${values.hour}:${values.minute}:${values.second} ${values.dayPeriod}`
}

function cleanString(value) {

	if (typeof value !== "string") {
		return ""
	}

	return value.trim()
}

function jsonResponse(data, status = 200) {

	return new Response(
		JSON.stringify(data),
		{
			status,
			headers: {
				"content-type": "application/json; charset=utf-8",
				"cache-control": "no-store",
				"x-content-type-options": "nosniff"
			}
		}
	)
}

export async function onRequest(context) {

	const { request, env } = context

	if (request.method !== "POST") {
		return jsonResponse(
			{
				success: false,
				error: "Method not allowed"
			},
			405
		)
	}

	if (!env.INTAKE_BUCKET) {
		return jsonResponse(
			{
				success: false,
				error: "Submission service unavailable"
			},
			500
		)
	}

	let form

	try {
		form = await request.formData()
	}
	catch {
		return jsonResponse(
			{
				success: false,
				error: "Invalid submission"
			},
			400
		)
	}

	const email = cleanString(form.get("email"))
	const name = cleanString(form.get("name"))
	const student = cleanString(form.get("student"))
	const text = cleanString(form.get("text"))

	if (!email) {
		return jsonResponse(
			{
				success: false,
				error: "Missing field: email address"
			},
			400
		)
	}

	if (!name) {
		return jsonResponse(
			{
				success: false,
				error: "Missing field: name"
			},
			400
		)
	}

	if (!student) {
		return jsonResponse(
			{
				success: false,
				error: "Missing field: student number"
			},
			400
		)
	}

	if (!text) {
		return jsonResponse(
			{
				success: false,
				error: "Missing field: hand-written text"
			},
			400
		)
	}

	if (email.length > MAX_EMAIL_LENGTH) {
		return jsonResponse(
			{
				success: false,
				error: "Email address is too long"
			},
			400
		)
	}

	if (name.length > MAX_NAME_LENGTH) {
		return jsonResponse(
			{
				success: false,
				error: "Name is too long"
			},
			400
		)
	}

	if (student.length > MAX_STUDENT_LENGTH) {
		return jsonResponse(
			{
				success: false,
				error: "Student number is too long"
			},
			400
		)
	}

	if (text.length > MAX_TEXT_LENGTH) {
		return jsonResponse(
			{
				success: false,
				error: "Text is too long"
			},
			400
		)
	}

	const timestamp = formatKSTTimestamp()
	const submissionId = crypto.randomUUID()

	const metadata = {
		"Timestamp": timestamp,
		"Email Address": email,
		"Your Name (한국어)": name,
		"Your Student Number (ex. 2021123456)": student,
		"Hand-written text (type exactly the text in your picture)": text
	}

	const objectPath =
		`submissions/${Date.now()}_${submissionId}.json`

	try {

		await env.INTAKE_BUCKET.put(
			objectPath,
			JSON.stringify(metadata, null, 2),
			{
				httpMetadata: {
					contentType: "application/json"
				},
				customMetadata: {
					submission_id: submissionId
				}
			}
		)

	}
	catch {

		return jsonResponse(
			{
				success: false,
				error: "Unable to save submission"
			},
			500
		)
	}

	return jsonResponse(
		{
			success: true,
			id: submissionId
		}
	)
}
