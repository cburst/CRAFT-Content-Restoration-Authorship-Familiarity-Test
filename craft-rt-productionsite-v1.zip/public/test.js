/* =========================================================
   CRAFT-RT STUDENT INTERFACE
   ========================================================= */


/* =========================================================
   BLOCK 1: DOM REFERENCES / STATE
   ========================================================= */

const testLayout =
	document.getElementById("test-layout");

const originalTextElement =
	document.getElementById("original-text");

const textPanel =
	document.getElementById("text-panel");

const instructionScrollCue =
	document.getElementById(
		"instruction-scroll-cue"
	);

const customScrollbar =
	document.getElementById(
		"custom-scrollbar"
	);

const customScrollbarThumb =
	document.getElementById(
		"custom-scrollbar-thumb"
	);

const questionNumberElement =
	document.getElementById("question-number");

const questionSentenceElement =
	document.getElementById("question-sentence");

const answerButtons =
	Array.from(
		document.querySelectorAll(".answer-button")
	);

const startButton =
	document.getElementById("start-button");

const navigation =
	document.getElementById("navigation");

const previousButton =
	document.getElementById("previous-button");

const nextButton =
	document.getElementById("next-button");

const statusMessage =
	document.getElementById("status-message");


const token =
	window.location.pathname
		.split("/")
		.filter(Boolean)
		.at(-1);


let currentViewId = null;
let currentQuestionNumber = null;
let totalQuestions = null;

let selectedAnswer = null;

let questionStartPerf = null;

let visibilityLossCount = 0;

let scrollEvents = [];
let activeScrollEvent = null;
let scrollEndTimer = null;

let navigationInProgress = false;

let instructionBottomReached = false;

let scrollbarDragging = false;
let scrollbarDragStartY = 0;
let scrollbarDragStartTop = 0;

/* =========================================================
   BLOCK 1A: CUSTOM SCROLLBAR
   ========================================================= */

function updateCustomScrollbar() {
	const viewportHeight =
		textPanel.clientHeight;

	const contentHeight =
		textPanel.scrollHeight;

	const trackHeight =
		customScrollbar.clientHeight;

	const trackPadding = 8;
	const thumbEndGap = 8;

	const usableTrackHeight =
		trackHeight -
		(trackPadding * 2);


	/*
	 * If the content does not require scrolling,
	 * hide the thumb.
	 */

	if (
		viewportHeight <= 0 ||
		contentHeight <= viewportHeight
	) {
		customScrollbarThumb.style.display =
			"none";

		return;
	}


	customScrollbarThumb.style.display =
		"block";


	/*
	 * Size the thumb in proportion to the amount
	 * of the document currently visible.
	 */

	const proportionalHeight =
		usableTrackHeight *
		(viewportHeight / contentHeight);

	const thumbHeight =
		Math.max(
			72,
			Math.min(
				usableTrackHeight -
				(thumbEndGap * 2),
				proportionalHeight
			)
		);


	/*
	 * Calculate how far the thumb and text
	 * are each capable of travelling.
	 *
	 * The thumb remains inset from both ends
	 * of the grey silhouette.
	 */

	const thumbTravel =
		usableTrackHeight -
		thumbHeight -
		(thumbEndGap * 2);

	const scrollTravel =
		contentHeight -
		viewportHeight;


	const scrollRatio =
		scrollTravel > 0
			? textPanel.scrollTop /
				scrollTravel
			: 0;


	const thumbTop =
		trackPadding +
		thumbEndGap +
		(thumbTravel * scrollRatio);


	customScrollbarThumb.style.height =
		`${thumbHeight}px`;

	customScrollbarThumb.style.top =
		`${thumbTop}px`;
}


/* Keep the visual thumb synchronized with normal scrolling. */

textPanel.addEventListener(
	"scroll",
	updateCustomScrollbar
);


window.addEventListener(
	"resize",
	() => {
		requestAnimationFrame(
			updateCustomScrollbar
		);
	}
);


/* =========================================================
   CLICKING THE SCROLLBAR TRACK
   ========================================================= */

customScrollbar.addEventListener(
	"mousedown",
	(event) => {
		if (
			event.target ===
			customScrollbarThumb
		) {
			return;
		}

		event.preventDefault();


		const trackPadding = 8;
		const thumbEndGap = 8;

		const trackRect =
			customScrollbar.getBoundingClientRect();

		const usableTrackHeight =
			customScrollbar.clientHeight -
			(trackPadding * 2);

		const thumbHeight =
			customScrollbarThumb.offsetHeight;

		const thumbTravel =
			usableTrackHeight -
			thumbHeight -
			(thumbEndGap * 2);


		if (thumbTravel <= 0) {
			return;
		}


		const clickY =
			event.clientY -
			trackRect.top -
			trackPadding -
			thumbEndGap;


		const desiredThumbPosition =
			Math.max(
				0,
				Math.min(
					thumbTravel,
					clickY -
					(thumbHeight / 2)
				)
			);


		const ratio =
			desiredThumbPosition /
			thumbTravel;


		const scrollTravel =
			textPanel.scrollHeight -
			textPanel.clientHeight;


		textPanel.scrollTop =
			ratio *
			scrollTravel;
	}
);


/* =========================================================
   DRAGGING THE SCROLLBAR THUMB
   ========================================================= */

customScrollbarThumb.addEventListener(
	"mousedown",
	(event) => {
		event.preventDefault();
		event.stopPropagation();

		scrollbarDragging = true;

		scrollbarDragStartY =
			event.clientY;

		scrollbarDragStartTop =
			customScrollbarThumb.offsetTop;
	}
);


window.addEventListener(
	"mousemove",
	(event) => {
		if (!scrollbarDragging) {
			return;
		}


		event.preventDefault();


		const trackPadding = 8;
		const thumbEndGap = 8;

		const usableTrackHeight =
			customScrollbar.clientHeight -
			(trackPadding * 2);

		const thumbHeight =
			customScrollbarThumb.offsetHeight;

		const thumbTravel =
			usableTrackHeight -
			thumbHeight -
			(thumbEndGap * 2);


		if (thumbTravel <= 0) {
			return;
		}


		const movement =
			event.clientY -
			scrollbarDragStartY;


		const desiredTop =
			scrollbarDragStartTop +
			movement;


		const minimumTop =
			trackPadding +
			thumbEndGap;

		const maximumTop =
			minimumTop +
			thumbTravel;


		const constrainedTop =
			Math.max(
				minimumTop,
				Math.min(
					maximumTop,
					desiredTop
				)
			);


		const ratio =
			(constrainedTop -
				minimumTop) /
			thumbTravel;


		const scrollTravel =
			textPanel.scrollHeight -
			textPanel.clientHeight;


		textPanel.scrollTop =
			ratio *
			scrollTravel;
	}
);


window.addEventListener(
	"mouseup",
	() => {
		scrollbarDragging = false;
	}
);

/* =========================================================
   BLOCK 2: INITIAL TEST LOAD / INSTRUCTIONS
   ========================================================= */

async function loadTest() {
	try {
		const response = await fetch(
			`/api/t/${encodeURIComponent(token)}`
		);

		const data = await response.json();

		if (!response.ok) {
			throw new Error(
				data.error || "Unable to load test."
			);
		}

		if (data.completed) {
			showCompletion();
			return;
		}

		if (data.started === false) {
			renderInstructions();
			return;
		}

		renderQuestion(data);

	} catch (error) {
		showStatus(error.message, true);
	}
}


function renderInstructions() {
	currentViewId = null;
	currentQuestionNumber = null;
	totalQuestions = null;
	selectedAnswer = null;
	questionStartPerf = null;

	instructionBottomReached = false;

	originalTextElement.innerHTML =
		`<div class="instruction-title">CRAFT-RT<br>(Content Restoration Authorship Familiarity Test)<br>(Response Time variant)</div><div>1. This test measures your familiarity with the text you recently submitted.

2. There are three possible answers for each question. Each answer describes the relationship between the sentence presented and your original text.

3. Original sentences appear exactly as they appeared in the original text.

4. Modified sentences are similar to sentences in the original text but have been changed slightly.

5. Fabricated sentences did not appear in the original text, but relate to the same topic.

6. Choose the correct type for each sentence presented.

7. Faster response times on correctly answered questions may indicate greater familiarity with the text.

8. Try to answer quickly, but remember that incorrect answers receive a 5-second penalty.</div>`;

	textPanel.scrollTop = 0;

	questionNumberElement.textContent = "";
	questionSentenceElement.textContent = "";

	for (const button of answerButtons) {
		button.style.display = "none";
	}

	startButton.style.display = "block";
	startButton.disabled = true;

	navigation.style.display = "none";

	instructionScrollCue.style.display =
		"flex";

	navigationInProgress = false;

	testLayout.hidden = false;

	/*
	 * If all instructions happen to fit without scrolling,
	 * there is nothing further for the student to expose.
	 *
	 * The custom scrollbar also needs to be recalculated
	 * after the instruction content has been rendered.
	 */

	requestAnimationFrame(
		() => {
			updateCustomScrollbar();
			updateInstructionScrollState();
		}
	);
}


function updateInstructionScrollState() {
	if (instructionBottomReached) {
		return;
	}

	const reachedBottom =
		textPanel.scrollTop +
		textPanel.clientHeight >=
		textPanel.scrollHeight - 2;

	if (!reachedBottom) {
		return;
	}

	instructionBottomReached = true;

	instructionScrollCue.style.display =
		"none";

	startButton.disabled = false;
}


textPanel.addEventListener(
	"scroll",
	updateInstructionScrollState
);


startButton.addEventListener(
	"click",
	async () => {
		if (
			navigationInProgress ||
			startButton.disabled
		) {
			return;
		}

		navigationInProgress = true;
		startButton.disabled = true;

		try {
			const response = await fetch(
				`/api/t/${encodeURIComponent(token)}/start`,
				{
					method: "POST"
				}
			);

			const data =
				await response.json();

			if (!response.ok) {
				throw new Error(
					data.error ||
					"Unable to start test."
				);
			}

			startButton.style.display = "none";

			instructionScrollCue.style.display =
				"none";

			/*
			 * The student has just scrolled to the bottom
			 * of the instructions. Return the left panel
			 * to the top BEFORE the first question is
			 * rendered so this movement is not recorded
			 * as test behavior.
			 */

			textPanel.scrollTop = 0;

			for (const button of answerButtons) {
				button.style.display = "";
			}

			navigation.style.display = "grid";

			renderQuestion(data);

		} catch (error) {
			navigationInProgress = false;
			startButton.disabled = false;

			showStatus(
				error.message,
				true
			);
		}
	}
);

/* =========================================================
   BLOCK 3: QUESTION RENDERING / TIMER START
   ========================================================= */

function renderQuestion(data) {
	currentViewId = data.view_id;
	currentQuestionNumber = data.question_number;
	totalQuestions = data.total_questions;

	originalTextElement.textContent =
		data.original_text;

	questionNumberElement.textContent =
		`• Question ${data.question_number} of ${data.total_questions}`;

	questionSentenceElement.textContent =
		data.question_sentence;

	selectedAnswer =
		data.saved_response ?? null;

	updateAnswerButtons();

	previousButton.disabled =
		!data.can_go_previous;

	if (data.is_last) {
		nextButton.innerHTML =
			"Save answers and<br>finish test";

		nextButton.classList.add(
			"finish-button"
		);

	} else {
		nextButton.innerHTML =
			"Save answer and<br>move to next question";

		nextButton.classList.remove(
			"finish-button"
		);
	}

	/*
	 * Start a completely new behavioral record for this view.
	 */

	visibilityLossCount = 0;
	scrollEvents = [];
	activeScrollEvent = null;

	if (scrollEndTimer !== null) {
		clearTimeout(scrollEndTimer);
		scrollEndTimer = null;
	}

	questionStartPerf =
		performance.now();

	navigationInProgress = false;

	setControlsDisabled(false);

	testLayout.hidden = false;
}

/* =========================================================
   BLOCK 4: ANSWER SELECTION
   ========================================================= */

for (const button of answerButtons) {
	button.addEventListener("click", () => {
		if (navigationInProgress) {
			return;
		}

		selectedAnswer =
			button.dataset.answer;

		updateAnswerButtons();
	});
}


function updateAnswerButtons() {
	for (const button of answerButtons) {
		const isSelected =
			button.dataset.answer ===
			selectedAnswer;

		button.classList.toggle(
			"selected",
			isSelected
		);

		button.setAttribute(
			"aria-pressed",
			isSelected ? "true" : "false"
		);
	}
}


/* =========================================================
   BLOCK 5: VISIBILITY / INTERRUPTION TRACKING
   ========================================================= */

document.addEventListener(
	"visibilitychange",
	() => {
		if (
			document.hidden &&
			currentViewId !== null
		) {
			visibilityLossCount += 1;
		}
	}
);


/* =========================================================
   BLOCK 6: ORIGINAL-TEXT SCROLL TRACKING
   ========================================================= */

/*
 * One scrolling event is treated as a continuous "burst".
 *
 * The burst begins on the first scroll event and finishes
 * after 150 ms without another scroll event.
 *
 * We preserve:
 *
 *   - start time
 *   - end time
 *   - duration
 *   - starting scroll position
 *   - ending scroll position
 *   - total absolute distance travelled
 *
 * Total distance is accumulated rather than merely taking
 * |end - start|, so scrolling down and then partly back up
 * is still represented accurately.
 *
 * The server accepts at most 200 scroll events per question
 * view. Once that limit is reached, additional bursts are
 * discarded locally so a legitimate navigation request is
 * never rejected merely because the student scrolled often.
 */

textPanel.addEventListener(
	"scroll",
	() => {
		if (
			currentViewId === null ||
			navigationInProgress
		) {
			return;
		}

		const nowPerf =
			performance.now();

		const nowEpoch =
			Date.now();

		const currentTop =
			textPanel.scrollTop;

		if (activeScrollEvent === null) {
			activeScrollEvent = {
				start_perf: nowPerf,
				start_epoch: nowEpoch,

				start_scroll_top:
					currentTop,

				last_scroll_top:
					currentTop,

				distance_px: 0
			};

		} else {
			activeScrollEvent.distance_px +=
				Math.abs(
					currentTop -
					activeScrollEvent.last_scroll_top
				);

			activeScrollEvent.last_scroll_top =
				currentTop;
		}

		if (scrollEndTimer !== null) {
			clearTimeout(scrollEndTimer);
		}

		scrollEndTimer =
			setTimeout(
				finishActiveScrollEvent,
				150
			);
	}
);


function finishActiveScrollEvent() {
	if (activeScrollEvent === null) {
		return;
	}

	const endPerf =
		performance.now();

	const endEpoch =
		Date.now();

	if (scrollEvents.length < 200) {
		scrollEvents.push({
			started_at:
				new Date(
					activeScrollEvent.start_epoch
				).toISOString(),

			ended_at:
				new Date(endEpoch).toISOString(),

			duration_ms:
				endPerf -
				activeScrollEvent.start_perf,

			start_scroll_top:
				activeScrollEvent.start_scroll_top,

			end_scroll_top:
				textPanel.scrollTop,

			distance_px:
				activeScrollEvent.distance_px
		});
	}

	activeScrollEvent = null;

	if (scrollEndTimer !== null) {
		clearTimeout(scrollEndTimer);
		scrollEndTimer = null;
	}
}

/* =========================================================
   BLOCK 7: PREVIOUS BUTTON
   ========================================================= */

previousButton.addEventListener(
	"click",
	async () => {
		if (
			navigationInProgress ||
			previousButton.disabled
		) {
			return;
		}

		await navigate("previous");
	}
);


/* =========================================================
   BLOCK 8: SAVE / NEXT / FINISH BUTTON
   ========================================================= */

nextButton.addEventListener(
	"click",
	async () => {
		if (navigationInProgress) {
			return;
		}

		if (selectedAnswer === null) {
			showStatus(
				"Please select an answer before continuing.",
				true
			);

			return;
		}

		const action =
			currentQuestionNumber === totalQuestions
				? "finish"
				: "next";

		await navigate(action);
	}
);


/* =========================================================
   BLOCK 9: NAVIGATION REQUEST
   ========================================================= */

async function navigate(action) {
	navigationInProgress = true;
	setControlsDisabled(true);

	/*
	 * Close a scroll burst that is still active at the exact
	 * moment the student clicks a navigation button.
	 */

	finishActiveScrollEvent();

	const clientRtMs =
		performance.now() -
		questionStartPerf;

	const payload = {
		view_id:
			currentViewId,

		action,

		/*
		 * Previous does NOT save the answer canonically,
		 * but we still send the currently selected response
		 * so that the behavioral history preserves what the
		 * student had selected during this viewing.
		 */

		response:
			selectedAnswer,

		client_rt_ms:
			clientRtMs,

		visibility_loss_count:
			visibilityLossCount,

		scroll_events:
			scrollEvents
	};

	try {
		const response = await fetch(
			`/api/t/${encodeURIComponent(token)}/navigate`,
			{
				method: "POST",

				headers: {
					"Content-Type":
						"application/json"
				},

				body:
					JSON.stringify(payload)
			}
		);

		const data =
			await response.json();

		if (!response.ok) {
			throw new Error(
				data.error ||
				"Unable to save test response."
			);
		}

		if (data.completed) {
			showCompletion();
			return;
		}

		renderQuestion(data);

	} catch (error) {
		navigationInProgress = false;
		setControlsDisabled(false);

		showStatus(
			error.message,
			true
		);
	}
}


/* =========================================================
   BLOCK 10: CONTROL STATE
   ========================================================= */

function setControlsDisabled(disabled) {
	for (const button of answerButtons) {
		button.disabled = disabled;
	}

	if (disabled) {
		previousButton.disabled = true;
		nextButton.disabled = true;

	} else {
		previousButton.disabled =
			currentQuestionNumber === 1;

		nextButton.disabled = false;
	}
}


/* =========================================================
   BLOCK 11: STATUS MESSAGE
   ========================================================= */

function showStatus(message, isError = false) {
	statusMessage.textContent = message;

	statusMessage.style.display =
		"block";

	statusMessage.setAttribute(
		"data-error",
		isError ? "true" : "false"
	);

	setTimeout(() => {
		statusMessage.style.display =
			"none";
	}, 3000);
}


/* =========================================================
   BLOCK 12: TEST COMPLETION
   ========================================================= */

function showCompletion() {
	currentViewId = null;
	navigationInProgress = true;

	document.body.innerHTML = `
		<main
			style="
				width:100vw;
				height:100vh;
				display:flex;
				align-items:center;
				justify-content:center;
				padding:40px;
				background:#fff;
				color:#000;
				font-family:var(--test-font);
				font-size:var(--test-font-size);
				font-weight:700;
				text-align:center;
			"
		>
			<div>
				<div
					style="
						margin-bottom:24px;
					"
				>
					• Test complete •
				</div>

				<div>
					Your answers have been saved.
				</div>
			</div>
		</main>
	`;
}

/* =========================================================
   BLOCK 13: START
   ========================================================= */

loadTest();
