import Papa from "papaparse";


/* =========================================================
   BLOCK 1: REQUEST ROUTER
   ========================================================= */

export default {
	async fetch(request, env) {
		try {
			const url = new URL(request.url);
			const path = url.pathname;
			const hostname = url.hostname;

			const isIntakeDomain =
				hostname === "intake.craftrt.org";

			const isTestDomain =
				hostname === "test.craftrt.org";

			const isWorkerDomain =
				hostname.endsWith(
					".workers.dev"
				);


			/*
			 * Worker health check:
			 *
			 *     GET /
			 *
			 * Keep this available on the workers.dev
			 * hostname for deployment testing.
			 */

			if (
				isWorkerDomain &&
				request.method === "GET" &&
				path === "/"
			) {
				return new Response(
					"CRAFT-RT Worker is running.",
					{
						status: 200,
						headers: {
							"Content-Type":
								"text/plain; charset=utf-8"
						}
					}
				);
			}


			/*
			 * Alternative CRAFT intake form:
			 *
			 *     https://intake.craftrt.org/
			 *     https://intake.craftrt.org/intake.html
			 *
			 * The intake form is a separate static page.
			 * Submissions are handled separately from the
			 * CRAFT-RT test system and stored in craft_intake.
			 */

			if (
				isIntakeDomain &&
				request.method === "GET" &&
				(
					path === "/" ||
					path === "/intake.html"
				)
			) {
				const assetUrl =
					new URL(request.url);

				assetUrl.pathname =
					"/intake.html";

				const assetResponse =
					await env.ASSETS.fetch(
						new Request(
							assetUrl,
							request
						)
					);

				const headers =
					new Headers(
						assetResponse.headers
					);

				headers.set(
					"X-Content-Type-Options",
					"nosniff"
				);

				headers.set(
					"Referrer-Policy",
					"no-referrer"
				);

				headers.set(
					"Cache-Control",
					"no-store"
				);

				headers.set(
					"X-Frame-Options",
					"DENY"
				);

				headers.set(
					"Content-Security-Policy",
					"default-src 'self'; " +
					"script-src 'self' 'unsafe-inline'; " +
					"style-src 'self' 'unsafe-inline'; " +
					"img-src 'self' data:; " +
					"connect-src 'self'; " +
					"object-src 'none'; " +
					"base-uri 'none'; " +
					"frame-ancestors 'none'; " +
					"form-action 'self'"
				);

				headers.set(
					"Permissions-Policy",
					"camera=(), microphone=(), geolocation=(), payment=(), usb=()"
				);

				return new Response(
					assetResponse.body,
					{
						status:
							assetResponse.status,
						statusText:
							assetResponse.statusText,
						headers
					}
				);
			}


			/*
			 * Intake submission:
			 *
			 *     POST
			 *     https://intake.craftrt.org/intake-upload
			 */

			if (
				isIntakeDomain &&
				request.method === "POST" &&
				path === "/intake-upload"
			) {
				return await intakeUpload(
					request,
					env
				);
			}


			/*
			 * Administrative test import.
			 *
			 * Keep this available through the existing
			 * workers.dev hostname because the local Python
			 * intake processor currently posts there.
			 *
			 * It is not exposed through either student-facing
			 * custom domain.
			 */

			if (
				isWorkerDomain &&
				request.method === "POST" &&
				path === "/import-test"
			) {
				const rateLimitResult =
					await env.IMPORT_RATE_LIMITER.limit({
						key:
							"import"
					});

				if (!rateLimitResult.success) {
					return jsonResponse(
						{
							error:
								"Too many requests"
						},
						429
					);
				}

				return await importTest(
					request,
					env,
					url
				);
			}


			/*
			 * Student-facing test page:
			 *
			 *     https://test.craftrt.org/t/<token>
			 *
			 * Serve the static test.html page while preserving
			 * the token in the browser's address bar.
			 */

			const studentMatch = path.match(
				/^\/t\/([A-Za-z0-9]+)$/
			);

			if (
				isTestDomain &&
				request.method === "GET" &&
				studentMatch
			) {
				const assetUrl =
					new URL(request.url);

				assetUrl.pathname =
					"/test.html";

				const assetResponse =
					await env.ASSETS.fetch(
						new Request(
							assetUrl,
							request
						)
					);

				const headers =
					new Headers(
						assetResponse.headers
					);

				headers.set(
					"X-Content-Type-Options",
					"nosniff"
				);

				headers.set(
					"Referrer-Policy",
					"no-referrer"
				);

				headers.set(
					"Cache-Control",
					"no-store"
				);

				headers.set(
					"X-Frame-Options",
					"DENY"
				);

				headers.set(
					"Content-Security-Policy",
					"default-src 'self'; " +
					"script-src 'self'; " +
					"style-src 'self' 'unsafe-inline'; " +
					"img-src 'self' data:; " +
					"connect-src 'self'; " +
					"object-src 'none'; " +
					"base-uri 'none'; " +
					"frame-ancestors 'none'; " +
					"form-action 'none'"
				);

				headers.set(
					"Permissions-Policy",
					"camera=(), microphone=(), geolocation=(), payment=(), usb=()"
				);

				return new Response(
					assetResponse.body,
					{
						status:
							assetResponse.status,
						statusText:
							assetResponse.statusText,
						headers
					}
				);
			}


			/*
			 * Browser API:
			 *
			 *     GET
			 *     https://test.craftrt.org/api/t/<token>
			 *
			 *     POST
			 *     https://test.craftrt.org/api/t/<token>/start
			 *
			 *     POST
			 *     https://test.craftrt.org/api/t/<token>/navigate
			 */

			const apiMatch = path.match(
				/^\/api\/t\/([A-Za-z0-9]+)(?:\/(start|navigate))?$/
			);

			if (
				isTestDomain &&
				apiMatch
			) {
				const token =
					apiMatch[1];

				const action =
					apiMatch[2];


				/*
				 * Test lookup / token validation.
				 *
				 * Rate-limit by client IP rather than by token.
				 * Otherwise an automated scanner could simply
				 * change the guessed token on every request.
				 */

				if (
					request.method === "GET" &&
					!action
				) {
					const clientIp =
						request.headers.get(
							"CF-Connecting-IP"
						) ||
						"unknown";

					const rateLimitResult =
						await env.TEST_LOOKUP_RATE_LIMITER.limit({
							key:
								`test-lookup:${clientIp}`
						});

					if (!rateLimitResult.success) {
						return jsonResponse(
							{
								error:
									"Too many requests"
							},
							429
						);
					}

					return await getTest(
						token,
						env
					);
				}


				/*
				 * Test start.
				 */

				if (
					request.method === "POST" &&
					action === "start"
				) {
					const rateLimitResult =
						await env.START_RATE_LIMITER.limit({
							key:
								`start:${token}`
						});

					if (!rateLimitResult.success) {
						return jsonResponse(
							{
								error:
									"Too many requests"
							},
							429
						);
					}

					return await startTest(
						token,
						env
					);
				}


				/*
				 * Test navigation.
				 */

				if (
					request.method === "POST" &&
					action === "navigate"
				) {
					const rateLimitResult =
						await env.NAVIGATE_RATE_LIMITER.limit({
							key:
								`navigate:${token}`
						});

					if (!rateLimitResult.success) {
						return jsonResponse(
							{
								error:
									"Too many requests"
							},
							429
						);
					}

					return await navigateTest(
						request,
						token,
						env
					);
				}
			}


			return jsonResponse(
				{ error: "Not found" },
				404
			);

		} catch (error) {
			console.error(error);

			return jsonResponse(
				{
					error:
						"Internal server error"
				},
				500
			);
		}
	}
};


/* =========================================================
   BLOCK 1A: ALTERNATIVE INTAKE FORM → R2
   ========================================================= */

async function intakeUpload(request, env) {
	const MAX_REQUEST_BODY_BYTES =
		131072;

	const MAX_EMAIL_LENGTH =
		320;

	const MAX_NAME_LENGTH =
		200;

	const MAX_STUDENT_LENGTH =
		100;

	const MAX_TEXT_LENGTH =
		100000;


	/*
	 * Reject obviously oversized submissions before
	 * parsing the multipart form body.
	 */

	const contentLength =
		request.headers.get(
			"Content-Length"
		);


	if (contentLength !== null) {
		const parsedContentLength =
			Number(contentLength);


		if (
			!Number.isInteger(
				parsedContentLength
			) ||
			parsedContentLength < 0
		) {
			return jsonResponse(
				{
					error:
						"Invalid submission."
				},
				400
			);
		}


		if (
			parsedContentLength >
			MAX_REQUEST_BODY_BYTES
		) {
			return jsonResponse(
				{
					error:
						"Submission is too large."
				},
				413
			);
		}
	}


	let form;


	try {
		form =
			await request.formData();

	} catch {
		return jsonResponse(
			{
				error:
					"Invalid submission."
			},
			400
		);
	}


	const cleanString =
		(value) => {
			if (
				typeof value !==
				"string"
			) {
				return "";
			}

			return value.trim();
		};


	const email =
		cleanString(
			form.get("email")
		);

	const name =
		cleanString(
			form.get("name")
		);

	const student =
		cleanString(
			form.get("student")
		);

	const text =
		cleanString(
			form.get("text")
		);


	if (!email) {
		return jsonResponse(
			{
				error:
					"Missing field: email address."
			},
			400
		);
	}


	if (!name) {
		return jsonResponse(
			{
				error:
					"Missing field: name."
			},
			400
		);
	}


	if (!student) {
		return jsonResponse(
			{
				error:
					"Missing field: student number."
			},
			400
		);
	}


	if (!text) {
		return jsonResponse(
			{
				error:
					"Missing field: hand-written text."
			},
			400
		);
	}


	if (
		email.length >
		MAX_EMAIL_LENGTH
	) {
		return jsonResponse(
			{
				error:
					"Email address is too long."
			},
			400
		);
	}


	if (
		name.length >
		MAX_NAME_LENGTH
	) {
		return jsonResponse(
			{
				error:
					"Name is too long."
			},
			400
		);
	}


	if (
		student.length >
		MAX_STUDENT_LENGTH
	) {
		return jsonResponse(
			{
				error:
					"Student number is too long."
			},
			400
		);
	}


	if (
		text.length >
		MAX_TEXT_LENGTH
	) {
		return jsonResponse(
			{
				error:
					"Text is too long."
			},
			400
		);
	}


	/*
	 * Basic server-side email validation.
	 *
	 * This is deliberately modest: the browser already
	 * uses type="email", while the server ensures that an
	 * obviously malformed value is not stored.
	 */

	if (
		!email.includes("@") ||
		email.startsWith("@") ||
		email.endsWith("@")
	) {
		return jsonResponse(
			{
				error:
					"Invalid email address."
			},
			400
		);
	}


	/*
	 * Match the Google Form/Google Sheets timestamp style
	 * while explicitly generating the value in Korea time.
	 */

	const timestampParts =
		new Intl.DateTimeFormat(
			"en-US",
			{
				timeZone:
					"Asia/Seoul",

				year:
					"numeric",

				month:
					"numeric",

				day:
					"numeric",

				hour:
					"numeric",

				minute:
					"2-digit",

				second:
					"2-digit",

				hour12:
					true
			}
		)
			.formatToParts(
				new Date()
			);


	const timestampValues = {};


	for (
		const part of
			timestampParts
	) {
		if (
			part.type !==
			"literal"
		) {
			timestampValues[
				part.type
			] =
				part.value;
		}
	}


	const timestamp =
		`${timestampValues.month}/` +
		`${timestampValues.day}/` +
		`${timestampValues.year} ` +
		`${timestampValues.hour}:` +
		`${timestampValues.minute}:` +
		`${timestampValues.second} ` +
		`${timestampValues.dayPeriod}`;


	const submissionId =
		crypto.randomUUID();


	/*
	 * These keys deliberately match the Google Form
	 * response-sheet columns exactly.
	 *
	 * intake.py can therefore normalize Google Form and
	 * Cloudflare intake submissions into the same schema.
	 */

	const submission = {
		"Timestamp":
			timestamp,

		"Email Address":
			email,

		"Your Name (한국어)":
			name,

		"Your Student Number (ex. 2021123456)":
			student,

		"Hand-written text (type exactly the text in your picture)":
			text
	};


	/*
	 * Date.now() keeps newly submitted objects naturally
	 * sortable by creation time.
	 *
	 * The UUID prevents collisions between submissions
	 * received during the same millisecond.
	 */

	const objectPath =
		`submissions/` +
		`${Date.now()}_` +
		`${submissionId}.json`;


	await env.craft_intake.put(
		objectPath,
		JSON.stringify(
			submission,
			null,
			2
		),
		{
			httpMetadata: {
				contentType:
					"application/json; charset=utf-8"
			},

			customMetadata: {
				submission_id:
					submissionId
			}
		}
	);


	return jsonResponse(
		{
			ok: true,
			id: submissionId
		}
	);
}



/* =========================================================
   BLOCK 2: TEST IMPORT — R2 CSV → D1
   ========================================================= */

async function importTest(request, env, url) {
	/*
	 * Test creation is an administrative operation.
	 *
	 * The secret must exist only on the Worker/server side.
	 * Students must never receive it in test.html, test.js,
	 * a URL, or an API response.
	 */

	const adminSecret =
		env.CRAFT_ADMIN_SECRET;

	if (!adminSecret) {
		console.error(
			"CRAFT_ADMIN_SECRET is not configured."
		);

		return jsonResponse(
			{
				error:
					"Administrative import is not configured."
			},
			500
		);
	}


	const authorization =
		request.headers.get(
			"Authorization"
		);

	const expectedAuthorization =
		`Bearer ${adminSecret}`;


	if (
		authorization !==
		expectedAuthorization
	) {
		return jsonResponse(
			{ error: "Unauthorized." },
			401
		);
	}


	const MAX_REQUEST_BODY_BYTES =
		16384;


	let body;

	try {
		body =
			await readJsonBodyWithLimit(
				request,
				MAX_REQUEST_BODY_BYTES
			);

	} catch (error) {
		if (
			error instanceof RequestBodyTooLargeError
		) {
			return jsonResponse(
				{
					error:
						"Request body is too large."
				},
				413
			);
		}

		return jsonResponse(
			{
				error:
					"Request body must contain valid JSON."
			},
			400
		);
	}


	if (
		!body ||
		typeof body !== "object" ||
		Array.isArray(body)
	) {
		return jsonResponse(
			{
				error:
					"Request body must be a JSON object."
			},
			400
		);
	}


	const allowedFields =
		new Set([
			"source_file"
		]);


	for (
		const field of
			Object.keys(body)
	) {
		if (
			!allowedFields.has(field)
		) {
			return jsonResponse(
				{
					error:
						"Request body contains an unexpected field."
				},
				400
			);
		}
	}


	const sourceFile =
		body.source_file;


	if (
		typeof sourceFile !== "string" ||
		sourceFile.length === 0 ||
		sourceFile.length > 1024
	) {
		return jsonResponse(
			{
				error:
					"source_file is required."
			},
			400
		);
	}


	const object =
		await env.craft_tests.get(
			sourceFile
		);


	if (!object) {
		return jsonResponse(
			{
				error:
					`R2 object not found: ${sourceFile}`
			},
			404
		);
	}


	const csvText =
		await object.text();


	const parsed =
		Papa.parse(
			csvText,
			{
				header: true,
				skipEmptyLines: true
			}
		);


	if (parsed.errors.length > 0) {
		return jsonResponse(
			{
				error:
					"CSV parsing failed.",

				details:
					parsed.errors
			},
			400
		);
	}


	const rows =
		parsed.data;


	const metadata =
		rows.find(
			(row) =>
				row.record_type ===
				"metadata"
		);


	const itemRows =
		rows.filter(
			(row) =>
				row.record_type ===
				"item"
		);


	if (!metadata) {
		return jsonResponse(
			{
				error:
					"CSV does not contain a metadata row."
			},
			400
		);
	}


	if (itemRows.length === 0) {
		return jsonResponse(
			{
				error:
					"CSV does not contain any item rows."
			},
			400
		);
	}


	const requiredMetadata = [
		"student_name",
		"student_id",
		"email",
		"original_text"
	];


	for (const field of requiredMetadata) {
		if (!metadata[field]) {
			return jsonResponse(
				{
					error:
						`Missing metadata field: ${field}`
				},
				400
			);
		}
	}


	const validAnswers =
		new Set([
			"original",
			"modified",
			"fabricated"
		]);


	const items = [];


	for (
		let index = 0;
		index < itemRows.length;
		index++
	) {
		const row =
			itemRows[index];


		if (!row.item_id) {
			return jsonResponse(
				{
					error:
						`Missing item_id on item row ${index + 1}.`
				},
				400
			);
		}


		if (!row.question_sentence) {
			return jsonResponse(
				{
					error:
						`Missing question_sentence for item ${row.item_id}.`
				},
				400
			);
		}


		const answerKey =
			String(
				row.answer_key || ""
			)
				.trim()
				.toLowerCase();


		if (
			!validAnswers.has(
				answerKey
			)
		) {
			return jsonResponse(
				{
					error:
						`Invalid answer_key for item ${row.item_id}.`
				},
				400
			);
		}


		items.push({
			item_id:
				String(
					row.item_id
				),

			original_order:
				index + 1,

			question_sentence:
				row.question_sentence,

			answer_key:
				answerKey
		});
	}


	shuffleArray(items);


	const instanceId =
		crypto.randomUUID();

	const accessToken =
		createAccessToken();


	await env.craft_db
		.prepare(`
			INSERT INTO test_instances (
				instance_id,
				source_file,
				student_name,
				student_id,
				email,
				original_text,
				access_token,
				total_items,
				current_position
			)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
		`)
		.bind(
			instanceId,
			sourceFile,
			metadata.student_name,
			metadata.student_id,
			metadata.email,
			metadata.original_text,
			accessToken,
			items.length
		)
		.run();


	for (
		let index = 0;
		index < items.length;
		index++
	) {
		const item =
			items[index];


		await env.craft_db
			.prepare(`
				INSERT INTO instance_items (
					instance_id,
					item_id,
					original_order,
					presentation_order,
					question_sentence,
					answer_key
				)
				VALUES (?, ?, ?, ?, ?, ?)
			`)
			.bind(
				instanceId,
				item.item_id,
				item.original_order,
				index + 1,
				item.question_sentence,
				item.answer_key
			)
			.run();
	}


	const testUrl =
		`https://test.craftrt.org/t/${accessToken}`;


	return jsonResponse({
		ok: true,
		instance_id:
			instanceId,
		total_items:
			items.length,
		test_url:
			testUrl
	});
}

/* =========================================================
   BLOCK 3: TEST DELIVERY / START / RELOAD RECOVERY
   ========================================================= */

async function getTest(token, env) {
	const instance =
		await getInstanceByToken(
			token,
			env
		);


	if (!instance) {
		return jsonResponse(
			{
				error:
					"Invalid test link."
			},
			404
		);
	}


	if (instance.completed_at) {
		return jsonResponse({
			ok: true,
			completed: true
		});
	}


	/*
	 * An unstarted test displays only the instruction screen.
	 *
	 * Do not create a question view, release Question 1,
	 * or start test timing until START THE TEST is clicked.
	 */

	if (!instance.started_at) {
		return jsonResponse({
			ok: true,
			completed: false,
			started: false
		});
	}


	const item =
		await getItemAtCurrentPosition(
			instance,
			env
		);


	if (!item) {
		return jsonResponse(
			{
				error:
					"Current question could not be found."
			},
			500
		);
	}


	/*
	 * If there is already an unfinished view for this item,
	 * this GET represents reload/recovery.
	 *
	 * Preserve its original server start time and increment
	 * reload_count rather than starting a new timer.
	 */

	let view =
		await getOpenView(
			instance.instance_id,
			item.item_id,
			env
		);


	if (view) {
		const reloadResult =
			await env.craft_db
				.prepare(`
					UPDATE item_views
					SET
						reload_count =
							reload_count + 1
					WHERE view_id = ?
					  AND ended_at IS NULL
				`)
				.bind(
					view.view_id
				)
				.run();


		const reloadRows =
			Number(
				reloadResult.meta?.changes || 0
			);


		/*
		 * The view may have been closed by a navigation
		 * request after getOpenView() read it but before the
		 * reload UPDATE executed.
		 *
		 * In that case, reload the authoritative test state
		 * rather than returning a stale, already-closed view.
		 */

		if (reloadRows !== 1) {
			return await getTest(
				token,
				env
			);
		}


		view.reload_count =
			Number(
				view.reload_count || 0
			) + 1;

	} else {
		view =
			await createView(
				instance.instance_id,
				item.item_id,
				"initial",
				env
			);
	}


	return jsonResponse(
		buildQuestionPayload(
			instance,
			item,
			view
		)
	);
}


async function startTest(token, env) {
	const instance =
		await getInstanceByToken(
			token,
			env
		);


	if (!instance) {
		return jsonResponse(
			{
				error:
					"Invalid test link."
			},
			404
		);
	}


	if (instance.completed_at) {
		return jsonResponse({
			ok: true,
			completed: true
		});
	}


	/*
	 * If the copy of the instance we just loaded already
	 * indicates that the test has started, reject the
	 * duplicate Start request immediately.
	 */

	if (instance.started_at) {
		return jsonResponse(
			{
				error:
					"Test has already started."
			},
			409
		);
	}


	const item =
		await getItemAtCurrentPosition(
			instance,
			env
		);


	if (!item) {
		return jsonResponse(
			{
				error:
					"Current question could not be found."
			},
			500
		);
	}


	const testStartedAt =
		new Date().toISOString();


	/*
	 * START THE TEST is the event that officially starts
	 * the test.
	 *
	 * The conditional UPDATE is also our concurrency guard.
	 * Only one request is allowed to change started_at from
	 * NULL to a timestamp.
	 */

	const startResult =
		await env.craft_db
			.prepare(`
				UPDATE test_instances
				SET started_at = ?
				WHERE instance_id = ?
				  AND started_at IS NULL
				  AND completed_at IS NULL
			`)
			.bind(
				testStartedAt,
				instance.instance_id
			)
			.run();


	const rowsChanged =
		Number(
			startResult.meta?.changes || 0
		);


	if (rowsChanged !== 1) {
		return jsonResponse(
			{
				error:
					"Test has already started."
			},
			409
		);
	}


	instance.started_at =
		testStartedAt;


	/*
	 * createView() records Question 1's released_at
	 * using the same server-generated view start time.
	 *
	 * The question payload is not returned to the browser
	 * until after this view exists.
	 */

	const view =
		await createView(
			instance.instance_id,
			item.item_id,
			"initial",
			env
		);


	return jsonResponse(
		buildQuestionPayload(
			instance,
			item,
			view
		)
	);
}

/* =========================================================
   BLOCK 4: NAVIGATION / TIMING / ANSWER SAVING
   ========================================================= */

async function navigateTest(request, token, env) {
	let body;


	const MAX_REQUEST_BODY_BYTES =
		65536;


	try {
		body =
			await readJsonBodyWithLimit(
				request,
				MAX_REQUEST_BODY_BYTES
			);

	} catch (error) {
		if (
			error instanceof RequestBodyTooLargeError
		) {
			return jsonResponse(
				{
					error:
						"Request body is too large."
				},
				413
			);
		}

		return jsonResponse(
			{
				error:
					"Request body must contain valid JSON."
			},
			400
		);
	}


	if (
		!body ||
		typeof body !== "object" ||
		Array.isArray(body)
	) {
		return jsonResponse(
			{
				error:
					"Request body must be a JSON object."
			},
			400
		);
	}


	const allowedFields =
		new Set([
			"view_id",
			"action",
			"response",
			"client_rt_ms",
			"visibility_loss_count",
			"scroll_events"
		]);


	for (
		const field of
			Object.keys(body)
	) {
		if (
			!allowedFields.has(field)
		) {
			return jsonResponse(
				{
					error:
						"Request body contains an unexpected field."
				},
				400
			);
		}
	}


	const instance =
		await getInstanceByToken(
			token,
			env
		);


	if (!instance) {
		return jsonResponse(
			{
				error:
					"Invalid test link."
			},
			404
		);
	}


	if (instance.completed_at) {
		return jsonResponse({
			ok: true,
			completed: true
		});
	}


	if (!instance.started_at) {
		return jsonResponse(
			{
				error:
					"Test has not started."
			},
			409
		);
	}


	const {
		view_id,
		action,
		response = null,
		client_rt_ms = null,
		visibility_loss_count = 0,
		scroll_events = []
	} = body;


	if (
		typeof view_id !== "string" ||
		view_id.length > 64 ||
		!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
			view_id
		)
	) {
		return jsonResponse(
			{
				error:
					"Invalid view_id."
			},
			400
		);
	}


	if (
		typeof action !== "string" ||
		![
			"previous",
			"next",
			"finish"
		].includes(action)
	) {
		return jsonResponse(
			{
				error:
					"Invalid navigation action."
			},
			400
		);
	}


	const validResponses =
		new Set([
			"original",
			"modified",
			"fabricated"
		]);


	if (
		response !== null &&
		(
			typeof response !== "string" ||
			!validResponses.has(
				response
			)
		)
	) {
		return jsonResponse(
			{
				error:
					"Invalid response."
			},
			400
		);
	}


	if (
		client_rt_ms !== null &&
		(
			typeof client_rt_ms !== "number" ||
			!Number.isFinite(
				client_rt_ms
			) ||
			client_rt_ms < 0 ||
			client_rt_ms > 86400000
		)
	) {
		return jsonResponse(
			{
				error:
					"Invalid client_rt_ms."
			},
			400
		);
	}


	if (
		typeof visibility_loss_count !== "number" ||
		!Number.isInteger(
			visibility_loss_count
		) ||
		visibility_loss_count < 0 ||
		visibility_loss_count > 10000
	) {
		return jsonResponse(
			{
				error:
					"Invalid visibility_loss_count."
			},
			400
		);
	}


	if (
		!Array.isArray(scroll_events)
	) {
		return jsonResponse(
			{
				error:
					"scroll_events must be an array."
			},
			400
		);
	}


	if (
		scroll_events.length > 200
	) {
		return jsonResponse(
			{
				error:
					"Too many scroll events."
			},
			400
		);
	}


	/*
	 * Moving forward requires an answer.
	 * Moving backward does not.
	 */

	if (
		(
			action === "next" ||
			action === "finish"
		) &&
		!response
	) {
		return jsonResponse(
			{
				error:
					"An answer must be selected before moving forward."
			},
			400
		);
	}


	const item =
		await getItemAtCurrentPosition(
			instance,
			env
		);


	if (!item) {
		return jsonResponse(
			{
				error:
					"Current question could not be found."
			},
			500
		);
	}


	/*
	 * Validate navigation bounds BEFORE closing the current
	 * view or writing timing/response data.
	 */

	const isFirstQuestion =
		instance.current_position === 0;


	const isLastQuestion =
		instance.current_position ===
		instance.total_items - 1;


	if (
		action === "previous" &&
		isFirstQuestion
	) {
		return jsonResponse(
			{
				error:
					"Cannot move previous from the first question."
			},
			400
		);
	}


	if (
		action === "next" &&
		isLastQuestion
	) {
		return jsonResponse(
			{
				error:
					"Cannot move next from the final question. Use finish."
			},
			400
		);
	}


	if (
		action === "finish" &&
		!isLastQuestion
	) {
		return jsonResponse(
			{
				error:
					"Cannot finish before the final question."
			},
			400
		);
	}


	/*
	 * A submitted view is valid only if:
	 *
	 *   1. it belongs to this access-token instance;
	 *   2. it belongs to the CURRENT server-side item;
	 *   3. it has not already been closed.
	 *
	 * This prevents arbitrary view IDs from being used to
	 * answer or navigate other questions.
	 */

	const view =
		await env.craft_db
			.prepare(`
				SELECT *
				FROM item_views
				WHERE view_id = ?
				  AND instance_id = ?
				  AND item_id = ?
				  AND ended_at IS NULL
				LIMIT 1
			`)
			.bind(
				view_id,
				instance.instance_id,
				item.item_id
			)
			.first();


	if (!view) {
		return jsonResponse(
			{
				error:
					"This question view is no longer active."
			},
			409
		);
	}


	const endedAt =
		new Date();


	const startedAt =
		new Date(
			view.started_at
		);


	const serverRtMs =
		Math.max(
			0,
			endedAt.getTime() -
			startedAt.getTime()
		);


	/*
	 * Client timing remains useful research/diagnostic data,
	 * but it originates in a browser controlled by the
	 * student and therefore cannot be authoritative.
	 */

	const validClientRt =
		Number.isFinite(
			Number(
				client_rt_ms
			)
		) &&
		Number(
			client_rt_ms
		) >= 0;


	const visibilityLossCount =
		Number.isInteger(
			Number(
				visibility_loss_count
			)
		)
			? Math.max(
				0,
				Number(
					visibility_loss_count
				)
			)
			: 0;


	/*
	 * Server timing is authoritative for scoring.
	 *
	 * A student may manipulate client_rt_ms, but cannot
	 * alter the server-generated started_at or the time at
	 * which this request reaches the Worker.
	 */

	let timingSource;


	if (
		view.reload_count > 0 ||
		visibilityLossCount > 0
	) {
		timingSource =
			"server_interruption";

	} else {
		timingSource =
			"server_authoritative";
	}


	const scoringRtMs =
		serverRtMs;


	const correct =
		response === null
			? null
			: response ===
				item.answer_key
				? 1
				: 0;


	const penaltyMs =
		correct === 0
			? 5000
			: 0;


	const adjustedRtMs =
		response === null
			? null
			: scoringRtMs +
				penaltyMs;


	/*
	 * response_changed compares what was selected during
	 * this view with the question's previously SAVED answer.
	 */

	const responseChanged =
		item.response !== null &&
		response !== null &&
		item.response !== response
			? 1
			: 0;


	const answerSaved =
		action === "next" ||
		action === "finish"
			? 1
			: 0;


	/*
	 * Close this view exactly once.
	 *
	 * The ended_at IS NULL condition makes view closure
	 * a one-use operation. If two requests race using the
	 * same view_id, only one UPDATE can succeed.
	 */

	const closeResult =
		await env.craft_db
			.prepare(`
				UPDATE item_views
				SET
					ended_at = ?,
					response = ?,
					response_changed = ?,
					correct = ?,
					client_rt_ms = ?,
					server_rt_ms = ?,
					scoring_rt_ms = ?,
					timing_source = ?,
					penalty_ms = ?,
					adjusted_rt_ms = ?,
					visibility_loss_count = ?,
					exit_action = ?,
					answer_saved = ?
				WHERE view_id = ?
				  AND instance_id = ?
				  AND item_id = ?
				  AND ended_at IS NULL
			`)
			.bind(
				endedAt.toISOString(),
				response,
				responseChanged,
				correct,
				validClientRt
					? Number(
						client_rt_ms
					)
					: null,
				serverRtMs,
				scoringRtMs,
				timingSource,
				penaltyMs,
				adjustedRtMs,
				visibilityLossCount,
				action,
				answerSaved,
				view_id,
				instance.instance_id,
				item.item_id
			)
			.run();


	const closedRows =
		Number(
			closeResult.meta?.changes || 0
		);


	if (closedRows !== 1) {
		return jsonResponse(
			{
				error:
					"This question view is no longer active."
			},
			409
		);
	}


	/*
	 * Behavioral scroll data belongs to the successfully
	 * closed view.
	 *
	 * This data is useful but remains client-originated and
	 * therefore is not treated as security-authoritative.
	 */

	await saveScrollEvents(
		view_id,
		scroll_events,
		env
	);


	/*
	 * Preserve the timing from the FIRST completed viewing
	 * of this item as its canonical item-level timing.
	 *
	 * A revisit may therefore change the saved ANSWER, but
	 * cannot replace the first-exposure reaction time with
	 * an artificially faster later reaction time.
	 */

	await env.craft_db
		.prepare(`
			UPDATE instance_items
			SET
				client_rt_ms =
					CASE
						WHEN scoring_rt_ms IS NULL
						THEN ?
						ELSE client_rt_ms
					END,

				server_rt_ms =
					CASE
						WHEN scoring_rt_ms IS NULL
						THEN ?
						ELSE server_rt_ms
					END,

				scoring_rt_ms =
					CASE
						WHEN scoring_rt_ms IS NULL
						THEN ?
						ELSE scoring_rt_ms
					END,

				timing_source =
					CASE
						WHEN scoring_rt_ms IS NULL
						THEN ?
						ELSE timing_source
					END

			WHERE instance_id = ?
			  AND item_id = ?
		`)
		.bind(
			validClientRt
				? Number(
					client_rt_ms
				)
				: null,
			serverRtMs,
			scoringRtMs,
			timingSource,
			instance.instance_id,
			item.item_id
		)
		.run();


	/*
	 * Only Save/Next or Finish changes the canonical answer.
	 *
	 * Notice that timing fields are NOT overwritten here.
	 * They already contain the first-exposure timing.
	 */

	if (answerSaved) {
		await env.craft_db
			.prepare(`
				UPDATE instance_items
				SET
					response = ?,
					correct = ?,
					penalty_ms = ?,
					adjusted_rt_ms =
						COALESCE(
							scoring_rt_ms,
							?
						) + ?,
					answered_at = ?

				WHERE instance_id = ?
				  AND item_id = ?
			`)
			.bind(
				response,
				correct,
				penaltyMs,
				scoringRtMs,
				penaltyMs,
				endedAt.toISOString(),
				instance.instance_id,
				item.item_id
			)
			.run();
	}


	/* ---------------------------------------------------------
	   PREVIOUS
	   --------------------------------------------------------- */

	if (action === "previous") {
		const newPosition =
			instance.current_position - 1;


		const positionResult =
			await env.craft_db
				.prepare(`
					UPDATE test_instances
					SET current_position = ?
					WHERE instance_id = ?
					  AND current_position = ?
					  AND completed_at IS NULL
				`)
				.bind(
					newPosition,
					instance.instance_id,
					instance.current_position
				)
				.run();


		const positionRows =
			Number(
				positionResult.meta?.changes || 0
			);


		if (positionRows !== 1) {
			return jsonResponse(
				{
					error:
						"Test position changed before navigation could complete."
				},
				409
			);
		}


		const targetItem =
			await getItemAtPosition(
				instance.instance_id,
				newPosition,
				env
			);


		if (!targetItem) {
			return jsonResponse(
				{
					error:
						"Previous question could not be found."
				},
				500
			);
		}


		const targetView =
			await createView(
				instance.instance_id,
				targetItem.item_id,
				"previous",
				env
			);


		const updatedInstance = {
			...instance,
			current_position:
				newPosition
		};


		return jsonResponse(
			buildQuestionPayload(
				updatedInstance,
				targetItem,
				targetView
			)
		);
	}


	/* ---------------------------------------------------------
	   FINISH
	   --------------------------------------------------------- */

	if (action === "finish") {
		const completedAt =
			endedAt.toISOString();


		const finishResult =
			await env.craft_db
				.prepare(`
					UPDATE test_instances
					SET completed_at = ?
					WHERE instance_id = ?
					  AND current_position = ?
					  AND completed_at IS NULL
				`)
				.bind(
					completedAt,
					instance.instance_id,
					instance.current_position
				)
				.run();


		const finishedRows =
			Number(
				finishResult.meta?.changes || 0
			);


		if (finishedRows !== 1) {
			return jsonResponse(
				{
					error:
						"Test state changed before completion could be recorded."
				},
				409
			);
		}


		try {
			await exportCompletedTest(
				instance.instance_id,
				completedAt,
				env
			);

		} catch (error) {
			console.error(
				"Completed-test export failed:",
				error
			);


			/*
			 * Roll completion back so the student can reload
			 * the final question and attempt Finish again.
			 *
			 * Any partially written R2 files are harmless:
			 * the next successful export overwrites them.
			 */

			await env.craft_db
				.prepare(`
					UPDATE test_instances
					SET completed_at = NULL
					WHERE instance_id = ?
					  AND completed_at = ?
				`)
				.bind(
					instance.instance_id,
					completedAt
				)
				.run();


			return jsonResponse(
				{
					error:
						"Result export failed. Reload the test and finish again."
				},
				500
			);
		}


		return jsonResponse({
			ok: true,
			completed: true
		});
	}


	/* ---------------------------------------------------------
	   NEXT
	   --------------------------------------------------------- */

	const newPosition =
		instance.current_position + 1;


	const positionResult =
		await env.craft_db
			.prepare(`
				UPDATE test_instances
				SET current_position = ?
				WHERE instance_id = ?
				  AND current_position = ?
				  AND completed_at IS NULL
			`)
			.bind(
				newPosition,
				instance.instance_id,
				instance.current_position
			)
			.run();


	const positionRows =
		Number(
			positionResult.meta?.changes || 0
		);


	if (positionRows !== 1) {
		return jsonResponse(
			{
				error:
					"Test position changed before navigation could complete."
			},
			409
		);
	}


	const targetItem =
		await getItemAtPosition(
			instance.instance_id,
			newPosition,
			env
		);


	if (!targetItem) {
		return jsonResponse(
			{
				error:
					"Next question could not be found."
			},
			500
		);
	}


	const targetView =
		await createView(
			instance.instance_id,
			targetItem.item_id,
			"next",
			env
		);


	const updatedInstance = {
		...instance,
		current_position:
			newPosition
	};


	return jsonResponse(
		buildQuestionPayload(
			updatedInstance,
			targetItem,
			targetView
		)
	);
}

/* =========================================================
   BLOCK 5: DATABASE LOOKUP HELPERS
   ========================================================= */

async function getInstanceByToken(token, env) {
	return await env.craft_db
		.prepare(`
			SELECT *
			FROM test_instances
			WHERE access_token = ?
			LIMIT 1
		`)
		.bind(token)
		.first();
}


async function getItemAtCurrentPosition(
	instance,
	env
) {
	return await getItemAtPosition(
		instance.instance_id,
		instance.current_position,
		env
	);
}


async function getItemAtPosition(
	instanceId,
	position,
	env
) {
	/*
	 * current_position is zero-based.
	 * presentation_order is one-based.
	 */

	return await env.craft_db
		.prepare(`
			SELECT *
			FROM instance_items
			WHERE instance_id = ?
			  AND presentation_order = ?
			LIMIT 1
		`)
		.bind(
			instanceId,
			position + 1
		)
		.first();
}


async function getOpenView(
	instanceId,
	itemId,
	env
) {
	return await env.craft_db
		.prepare(`
			SELECT *
			FROM item_views
			WHERE instance_id = ?
			  AND item_id = ?
			  AND ended_at IS NULL
			ORDER BY view_number DESC
			LIMIT 1
		`)
		.bind(
			instanceId,
			itemId
		)
		.first();
}


/* =========================================================
   BLOCK 6: VIEW CREATION / QUESTION PAYLOAD
   ========================================================= */

async function createView(
	instanceId,
	itemId,
	navigationFrom,
	env
) {
	const viewId =
		crypto.randomUUID();

	const startedAt =
		new Date().toISOString();

	/*
	 * Record when this item is first released to the student.
	 *
	 * Revisiting the item does not overwrite its original
	 * release timestamp.
	 */

	await env.craft_db
		.prepare(`
			UPDATE instance_items
			SET released_at = ?
			WHERE instance_id = ?
			  AND item_id = ?
			  AND released_at IS NULL
		`)
		.bind(
			startedAt,
			instanceId,
			itemId
		)
		.run();

	/*
	 * Create at most one open view for this item.
	 *
	 * Both the next view_number calculation and the
	 * "no existing open view" check occur inside the same
	 * INSERT statement.
	 *
	 * The database also enforces a unique partial index on
	 * (instance_id, item_id) while ended_at IS NULL.
	 *
	 * INSERT OR IGNORE therefore allows concurrent requests
	 * to converge safely: one request creates the open view,
	 * while any competing insert is ignored and retrieves
	 * the authoritative existing view below.
	 */

	const insertResult =
		await env.craft_db
			.prepare(`
				INSERT OR IGNORE INTO item_views (
					view_id,
					instance_id,
					item_id,
					view_number,
					started_at,
					navigation_from
				)

				SELECT
					?,
					?,
					?,
					(
						SELECT
							COALESCE(
								MAX(view_number),
								0
							) + 1
						FROM item_views
						WHERE instance_id = ?
						  AND item_id = ?
					),
					?,
					?

				WHERE NOT EXISTS (
					SELECT 1
					FROM item_views
					WHERE instance_id = ?
					  AND item_id = ?
					  AND ended_at IS NULL
				)
			`)
			.bind(
				viewId,
				instanceId,
				itemId,
				instanceId,
				itemId,
				startedAt,
				navigationFrom,
				instanceId,
				itemId
			)
			.run();

	const insertedRows =
		Number(
			insertResult.meta?.changes || 0
		);

	/*
	 * If this request created the view, read it back so the
	 * returned data comes from the authoritative database
	 * record.
	 */

	if (insertedRows === 1) {
		const createdView =
			await env.craft_db
				.prepare(`
					SELECT *
					FROM item_views
					WHERE view_id = ?
					LIMIT 1
				`)
				.bind(
					viewId
				)
				.first();

		if (!createdView) {
			throw new Error(
				"Created question view could not be read."
			);
		}

		return createdView;
	}

	/*
	 * Another concurrent request may have created the open
	 * view first. In that case, return that authoritative
	 * existing view rather than creating a duplicate.
	 */

	const existingView =
		await env.craft_db
			.prepare(`
				SELECT *
				FROM item_views
				WHERE instance_id = ?
				  AND item_id = ?
				  AND ended_at IS NULL
				ORDER BY view_number DESC
				LIMIT 1
			`)
			.bind(
				instanceId,
				itemId
			)
			.first();

	if (!existingView) {
		throw new Error(
			"Question view could not be created."
		);
	}

	return existingView;
}


function buildQuestionPayload(
	instance,
	item,
	view
) {
	const questionNumber =
		instance.current_position + 1;

	return {
		ok: true,
		completed: false,

		original_text:
			instance.original_text,

		question_number:
			questionNumber,

		total_questions:
			instance.total_items,

		question_sentence:
			item.question_sentence,

		saved_response:
			item.response ?? null,

		view_id:
			view.view_id,

		view_number:
			view.view_number,

		reload_count:
			view.reload_count ?? 0,

		can_go_previous:
			instance.current_position > 0,

		is_last:
			questionNumber ===
			instance.total_items
	};
}

/* =========================================================
   BLOCK 7: SCROLL-EVENT STORAGE
   ========================================================= */

async function saveScrollEvents(
	viewId,
	scrollEvents,
	env
) {
	const MAX_SCROLL_EVENTS = 200;
	const MAX_SCROLL_DURATION_MS = 600000;
	const MAX_SCROLL_POSITION_PX = 10000000;
	const MAX_SCROLL_DISTANCE_PX = 10000000;

	if (!Array.isArray(scrollEvents)) {
		return;
	}

	const limitedEvents =
		scrollEvents.slice(
			0,
			MAX_SCROLL_EVENTS
		);

	for (
		let index = 0;
		index < limitedEvents.length;
		index++
	) {
		const event = limitedEvents[index];

		if (
			!event ||
			typeof event !== "object"
		) {
			continue;
		}

		const durationMs =
			Number(event.duration_ms);

		const startScrollTop =
			Number(event.start_scroll_top);

		const endScrollTop =
			Number(event.end_scroll_top);

		const distancePx =
			Number(event.distance_px);

		if (
			!Number.isFinite(durationMs) ||
			!Number.isFinite(startScrollTop) ||
			!Number.isFinite(endScrollTop) ||
			!Number.isFinite(distancePx)
		) {
			continue;
		}

		if (
			durationMs < 0 ||
			durationMs > MAX_SCROLL_DURATION_MS ||
			startScrollTop < 0 ||
			startScrollTop > MAX_SCROLL_POSITION_PX ||
			endScrollTop < 0 ||
			endScrollTop > MAX_SCROLL_POSITION_PX ||
			Math.abs(distancePx) >
				MAX_SCROLL_DISTANCE_PX
		) {
			continue;
		}

		if (
			typeof event.started_at !== "string" ||
			typeof event.ended_at !== "string"
		) {
			continue;
		}

		await env.craft_db
			.prepare(`
				INSERT INTO scroll_events (
					scroll_event_id,
					view_id,
					event_number,
					started_at,
					ended_at,
					duration_ms,
					start_scroll_top,
					end_scroll_top,
					distance_px
				)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
			`)
			.bind(
				crypto.randomUUID(),
				viewId,
				index + 1,
				event.started_at,
				event.ended_at,
				durationMs,
				startScrollTop,
				endScrollTop,
				Math.abs(distancePx)
			)
			.run();
	}
}

/* =========================================================
   BLOCK 8A: COMPLETED TEST CSV EXPORT
   ========================================================= */

async function exportCompletedTest(
	instanceId,
	completedAt,
	env
) {
	/*
	 * Load the test-level metadata.
	 */

	const instance = await env.craft_db
		.prepare(`
			SELECT
				instance_id,
				source_file,
				student_name,
				student_id,
				email,
				total_items,
				started_at,
				completed_at,
				created_at
			FROM test_instances
			WHERE instance_id = ?
			LIMIT 1
		`)
		.bind(instanceId)
		.first();

	if (!instance) {
		throw new Error(
			`Cannot export missing instance: ${instanceId}`
		);
	}

	/*
	 * Shared test-level metadata.
	 *
	 * test_started_at is deliberately named differently
	 * from the view/scroll started_at fields.
	 */

	const exportMetadata = {
		instance_id: instance.instance_id,
		source_file: instance.source_file,
		student_name: instance.student_name,
		student_id: instance.student_id,
		email: instance.email,
		total_items: instance.total_items,
		test_started_at: instance.started_at,
		completed_at: completedAt,
		created_at: instance.created_at
	};

	/* ---------------------------------------------------------
	   RESULTS.CSV
	   One row per canonical test item
	   --------------------------------------------------------- */

	const itemQuery = await env.craft_db
		.prepare(`
			SELECT
				item_id,
				original_order,
				presentation_order,
				question_sentence,
				answer_key,
				response,
				correct,
				client_rt_ms,
				server_rt_ms,
				scoring_rt_ms,
				timing_source,
				penalty_ms,
				adjusted_rt_ms,
				released_at,
				answered_at
			FROM instance_items
			WHERE instance_id = ?
			ORDER BY presentation_order
		`)
		.bind(instanceId)
		.all();

	const resultRows =
		itemQuery.results.map((row) => ({
			...exportMetadata,
			...row
		}));

	/* ---------------------------------------------------------
	   VIEWS.CSV
	   One row per viewing of a question
	   --------------------------------------------------------- */

	const viewQuery = await env.craft_db
		.prepare(`
			SELECT
				v.view_id,
				v.item_id,
				i.presentation_order,
				i.question_sentence,
				i.answer_key,
				v.view_number,
				v.started_at,
				v.ended_at,
				v.navigation_from,
				v.response,
				v.response_changed,
				v.correct,
				v.client_rt_ms,
				v.server_rt_ms,
				v.scoring_rt_ms,
				v.timing_source,
				v.penalty_ms,
				v.adjusted_rt_ms,
				v.reload_count,
				v.visibility_loss_count,
				v.exit_action,
				v.answer_saved
			FROM item_views AS v
			JOIN instance_items AS i
				ON i.instance_id = v.instance_id
			   AND i.item_id = v.item_id
			WHERE v.instance_id = ?
			ORDER BY
				i.presentation_order,
				v.view_number
		`)
		.bind(instanceId)
		.all();

	const viewRows =
		viewQuery.results.map((row) => ({
			...exportMetadata,
			...row
		}));

	/* ---------------------------------------------------------
	   SCROLLS.CSV
	   One row per recorded scroll burst
	   --------------------------------------------------------- */

	const scrollQuery = await env.craft_db
		.prepare(`
			SELECT
				s.scroll_event_id,
				v.view_id,
				v.item_id,
				i.presentation_order,
				v.view_number,
				s.event_number,
				s.started_at,
				s.ended_at,
				s.duration_ms,
				s.start_scroll_top,
				s.end_scroll_top,
				s.distance_px
			FROM scroll_events AS s
			JOIN item_views AS v
				ON v.view_id = s.view_id
			JOIN instance_items AS i
				ON i.instance_id = v.instance_id
			   AND i.item_id = v.item_id
			WHERE v.instance_id = ?
			ORDER BY
				i.presentation_order,
				v.view_number,
				s.event_number
		`)
		.bind(instanceId)
		.all();

	const scrollRows =
		scrollQuery.results.map((row) => ({
			...exportMetadata,
			...row
		}));

	/* ---------------------------------------------------------
	   CSV COLUMN DEFINITIONS
	   --------------------------------------------------------- */

	const resultsColumns = [
		"instance_id",
		"source_file",
		"student_name",
		"student_id",
		"email",
		"total_items",
		"test_started_at",
		"completed_at",
		"created_at",
		"item_id",
		"original_order",
		"presentation_order",
		"question_sentence",
		"answer_key",
		"response",
		"correct",
		"client_rt_ms",
		"server_rt_ms",
		"scoring_rt_ms",
		"timing_source",
		"penalty_ms",
		"adjusted_rt_ms",
		"released_at",
		"answered_at"
	];

	const viewsColumns = [
		"instance_id",
		"source_file",
		"student_name",
		"student_id",
		"email",
		"total_items",
		"test_started_at",
		"completed_at",
		"created_at",
		"view_id",
		"item_id",
		"presentation_order",
		"question_sentence",
		"answer_key",
		"view_number",
		"started_at",
		"ended_at",
		"navigation_from",
		"response",
		"response_changed",
		"correct",
		"client_rt_ms",
		"server_rt_ms",
		"scoring_rt_ms",
		"timing_source",
		"penalty_ms",
		"adjusted_rt_ms",
		"reload_count",
		"visibility_loss_count",
		"exit_action",
		"answer_saved"
	];

	const scrollsColumns = [
		"instance_id",
		"source_file",
		"student_name",
		"student_id",
		"email",
		"total_items",
		"test_started_at",
		"completed_at",
		"created_at",
		"scroll_event_id",
		"view_id",
		"item_id",
		"presentation_order",
		"view_number",
		"event_number",
		"started_at",
		"ended_at",
		"duration_ms",
		"start_scroll_top",
		"end_scroll_top",
		"distance_px"
	];

	/* ---------------------------------------------------------
	   CREATE CSV STRINGS
	   --------------------------------------------------------- */

	const resultsCsv =
		rowsToCsv(
			resultRows,
			resultsColumns
		);

	const viewsCsv =
		rowsToCsv(
			viewRows,
			viewsColumns
		);

	const scrollsCsv =
		rowsToCsv(
			scrollRows,
			scrollsColumns
		);

	/* ---------------------------------------------------------
	   R2 FOLDER

	   results/
	     <student_id>_<instance_id>/
	       results.csv
	       views.csv
	       scrolls.csv
	   --------------------------------------------------------- */

	const safeStudentId =
		safeR2PathSegment(
			instance.student_id
		);

	const folder =
		`results/${safeStudentId}_${instanceId}`;

	const csvMetadata = {
		httpMetadata: {
			contentType:
				"text/csv; charset=utf-8"
		}
	};

	await env.craft_tests.put(
		`${folder}/results.csv`,
		resultsCsv,
		csvMetadata
	);

	await env.craft_tests.put(
		`${folder}/views.csv`,
		viewsCsv,
		csvMetadata
	);

	await env.craft_tests.put(
		`${folder}/scrolls.csv`,
		scrollsCsv,
		csvMetadata
	);

	console.log(
		`Completed test exported to ${folder}/`
	);
}


/* ---------------------------------------------------------
   CSV HELPERS
   --------------------------------------------------------- */

function rowsToCsv(rows, columns) {
	const lines = [];

	lines.push(
		columns
			.map(csvEscape)
			.join(",")
	);

	for (const row of rows) {
		lines.push(
			columns
				.map((column) =>
					csvEscape(row[column])
				)
				.join(",")
		);
	}

	/*
	 * UTF-8 BOM improves compatibility with Excel,
	 * especially for Korean names/text.
	 */

	return "\uFEFF" + lines.join("\n");
}


function csvEscape(value) {
	if (
		value === null ||
		value === undefined
	) {
		return "";
	}

	const text =
		String(value);

	if (
		text.includes(",") ||
		text.includes('"') ||
		text.includes("\n") ||
		text.includes("\r")
	) {
		return `"${text.replaceAll('"', '""')}"`;
	}

	return text;
}


function safeR2PathSegment(value) {
	return String(value)
		.trim()
		.replace(
			/[^A-Za-z0-9._-]+/g,
			"_"
		);
}


/* =========================================================
   BLOCK 8: GENERAL HELPERS
   ========================================================= */

class RequestBodyTooLargeError extends Error {
	constructor() {
		super(
			"Request body is too large."
		);

		this.name =
			"RequestBodyTooLargeError";
	}
}


async function readJsonBodyWithLimit(
	request,
	maxBytes
) {
	const contentLength =
		request.headers.get(
			"Content-Length"
		);


	if (contentLength !== null) {
		const parsedContentLength =
			Number(contentLength);


		if (
			!Number.isInteger(
				parsedContentLength
			) ||
			parsedContentLength < 0
		) {
			throw new SyntaxError(
				"Invalid Content-Length."
			);
		}


		if (
			parsedContentLength >
			maxBytes
		) {
			throw new RequestBodyTooLargeError();
		}
	}


	if (!request.body) {
		throw new SyntaxError(
			"Request body is empty."
		);
	}


	const reader =
		request.body.getReader();

	const chunks = [];

	let totalBytes = 0;


	try {
		while (true) {
			const {
				done,
				value
			} =
				await reader.read();


			if (done) {
				break;
			}


			if (!value) {
				continue;
			}


			totalBytes +=
				value.byteLength;


			if (
				totalBytes >
				maxBytes
			) {
				try {
					await reader.cancel();

				} catch {
					/*
					 * Ignore cancellation errors.
					 * The request is already being rejected.
					 */
				}

				throw new RequestBodyTooLargeError();
			}


			chunks.push(value);
		}

	} finally {
		reader.releaseLock();
	}


	const bodyBytes =
		new Uint8Array(
			totalBytes
		);


	let offset = 0;


	for (const chunk of chunks) {
		bodyBytes.set(
			chunk,
			offset
		);

		offset +=
			chunk.byteLength;
	}


	const decoder =
		new TextDecoder(
			"utf-8",
			{
				fatal: true
			}
		);


	const bodyText =
		decoder.decode(
			bodyBytes
		);


	return JSON.parse(
		bodyText
	);
}


function jsonResponse(data, status = 200) {
	return new Response(
		JSON.stringify(data),
		{
			status,
			headers: {
				"Content-Type":
					"application/json; charset=utf-8",

				"X-Content-Type-Options":
					"nosniff",

				"Referrer-Policy":
					"no-referrer",

				"Cache-Control":
					"no-store"
			}
		}
	);
}


function createAccessToken() {
	return (
		crypto.randomUUID().replaceAll("-", "") +
		crypto.randomUUID().replaceAll("-", "")
	);
}


function shuffleArray(array) {
	for (
		let i = array.length - 1;
		i > 0;
		i--
	) {
		const range =
			i + 1;

		const maxUint32 =
			0x100000000;

		const rejectionLimit =
			maxUint32 -
			(maxUint32 % range);

		let randomValue;

		do {
			const randomValues =
				new Uint32Array(1);

			crypto.getRandomValues(
				randomValues
			);

			randomValue =
				randomValues[0];

		} while (
			randomValue >=
			rejectionLimit
		);

		const j =
			randomValue % range;

		[array[i], array[j]] =
			[array[j], array[i]];
	}
}
